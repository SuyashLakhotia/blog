/* Query 1 */
SELECT AVG(R.price)
FROM Requests R, ConfirmedBookings CB
WHERE R.RequestID = CB.RequestID AND YEAR(CB.ConfirmedDateTime) = 2015 AND MONTH(CB.ConfirmedDateTime) = 12 AND CAST(CB.ConfirmedDateTime as time) BETWEEN '18:00:00' AND '21:00:00';


/* Query 2 */
SELECT CB.Driver_PersonID AS DriverID
INTO #DecemberFiveRatings
FROM CompletedTrips CT, ConfirmedBookings CB
WHERE CT.Rating = 5 AND CB.RequestID = CT.RequestID AND YEAR(CB.ConfirmedDateTime) = 2015 AND MONTH(CB.ConfirmedDateTime) = 12;

SELECT DriverID, COUNT(*) AS NumRatings
INTO #HundredFive
FROM #DecemberFiveRatings
GROUP BY DriverID
HAVING COUNT(*) >= 100;

SELECT CB.Driver_PersonID as DriverID, AVG(CAST (CT.Rating AS FLOAT)) AS AvgRating
INTO #DriverAvgRating
FROM CompletedTrips CT, ConfirmedBookings CB
WHERE CB.RequestID = CT.RequestID
GROUP BY CB.Driver_PersonID;

SELECT H.DriverID, FirstName, LastName, AvgRating
FROM #HundredFive H, #DriverAvgRating A, Drivers D
WHERE H.DriverID = A.DriverID AND H.DriverID = D.PersonID
ORDER BY A.AvgRating;

DROP TABLE #DecemberFiveRatings;
DROP TABLE #HundredFive;
DROP TABLE #DriverAvgRating;


/* Query 3 */
SELECT AVG(DATEDIFF(MINUTE, C.ConfirmedDateTime, CB.CancelDateTime))
FROM CancelledBookings CB, ConfirmedBookings C
WHERE CB.RequestID = C.RequestID AND MONTH(C.ConfirmedDateTime) = 12 AND YEAR(C.ConfirmedDateTime) = 2015;


/* Query 4 */
SELECT Employee_PersonID, DATEDIFF(MINUTE, StartDateTime, ProcessedDateTime) AS Latency
INTO #LatencyTable
FROM Complaints;

SELECT Employee_PersonID, AVG(Latency) AS AvgLatency
INTO #AvgLatencyTable
FROM #LatencyTable
GROUP BY Employee_PersonID;

SELECT *
FROM Employees E
WHERE E.PersonID = (SELECT Employee_PersonID FROM #AvgLatencyTable WHERE AvgLatency <= ALL(SELECT AvgLatency FROM #AvgLatencyTable));

DROP TABLE #LatencyTable;
DROP TABLE #AvgLatencyTable;


/* Query 5 */
SELECT C.Brand, C.Model, COUNT(C.CarPlateNum)
FROM Cars C
GROUP BY C.Brand, C.Model;
