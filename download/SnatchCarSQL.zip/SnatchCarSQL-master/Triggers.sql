/* Trigger 1 */
CREATE TRIGGER CheckCarPlateNum ON dbo.Cars
FOR INSERT, UPDATE
AS
BEGIN
	IF NOT EXISTS(SELECT D.CarPlateNum FROM dbo.Drivers D, INSERTED I WHERE D.CarPlateNum = I.CarPlateNum)
		BEGIN
			RAISERROR('Insertion/Update not allowed. CarPlateNum has not been assigned to a Driver.',-1,-1)
			ROLLBACK
		END
END


/* Trigger 2.1 */
CREATE TRIGGER CheckDriver ON dbo.ConfirmedBookings
FOR INSERT, UPDATE
AS
BEGIN
	declare @driverid CHAR(9);
	
	SELECT @driverid = I.Driver_PersonID FROM INSERTED I;
	
	IF @driverid IS NOT NULL AND NOT EXISTS(SELECT PersonID FROM dbo.Drivers D WHERE D.PersonID = @driverid)
		BEGIN
			RAISERROR('Insertion/Update not allowed. Driver does not exist.',-1,-1)
			ROLLBACK
		END
END

/* Trigger 2.2 */
CREATE TRIGGER UpdateConfirmedBookingsUpdate ON dbo.Drivers
AFTER UPDATE
AS
BEGIN
	declare @old_driverid CHAR(9);
	declare @new_driverid CHAR(9);

	SELECT @old_driverid = D.PersonID FROM DELETED D;
	SELECT @new_driverid = I.PersonID FROM INSERTED I;

	UPDATE dbo.ConfirmedBookings SET Driver_PersonID = @new_driverid WHERE Driver_PersonID = @old_driverid;
END

/* Trigger 2.3 */
CREATE TRIGGER UpdateConfirmedBookingsDelete ON dbo.Drivers
AFTER DELETE
AS
BEGIN
	declare @old_driverid CHAR(9);

	SELECT @old_driverid = D.PersonID FROM DELETED D;

	UPDATE dbo.ConfirmedBookings SET Driver_PersonID = NULL WHERE Driver_PersonID = @old_driverid;
END


/* Trigger 3.1 */
CREATE TRIGGER CheckEmployee ON dbo.Complaints
AFTER INSERT, UPDATE
AS
BEGIN
	declare @employeeid CHAR(9);
	
	SELECT @employeeid = Employee_PersonID FROM INSERTED;

	IF @employeeid IS NOT NULL AND NOT EXISTS (SELECT PersonID FROM dbo.Employees WHERE PersonID = @employeeid)
	BEGIN
		RAISERROR('Insertion/Update not allowed. Employee does not exist.',-1,-1)
		ROLLBACK
	END
END

/* Trigger 3.2 */
CREATE TRIGGER UpdateComplaintsUpdate ON dbo.Employees
AFTER UPDATE
AS
BEGIN
	declare @new_employeeid CHAR(9);
	declare @old_employeeid CHAR(9);

	SELECT @new_employeeid = I.PersonID FROM INSERTED I;
	SELECT @old_employeeid = D.PersonID FROM DELETED D;

	UPDATE dbo.Complaints SET Employee_PersonID = @new_employeeid WHERE Employee_PersonID = @old_employeeid;
END

/* Trigger 3.3 */
CREATE TRIGGER UpdateComplaintsDelete ON dbo.Employees
AFTER DELETE
AS
BEGIN
	declare @old_employeeid CHAR(9);

	SELECT @old_employeeid = D.PersonID FROM DELETED D;

	UPDATE dbo.Complaints SET Employee_PersonID = NULL WHERE Employee_PersonID = @old_employeeid;
END


/* Trigger 4.1 */
CREATE TRIGGER CheckCancelDateTime ON dbo.CancelledBookings
FOR INSERT, UPDATE
AS 
BEGIN
	declare @canceldatetime DATETIME;
	declare @confirmdatetime DATETIME;

	SELECT @canceldatetime = I.CancelDateTime FROM INSERTED I; 
	SELECT @confirmdatetime = ConfirmedDateTime
	FROM dbo.ConfirmedBookings CB, INSERTED I WHERE CB.RequestID = I.RequestID;
	
	IF CAST(@canceldatetime as FLOAT) <  CAST(@confirmdatetime as FLOAT)
		BEGIN
			RAISERROR('CancelDateTime is earlier than ConfirmedDateTime. Cannot save to database.',-1,-1)
			ROLLBACK
		END
END

/* Trigger 4.2 */
CREATE TRIGGER CheckNoShowDateTime ON dbo.NoShowBookings
FOR INSERT, UPDATE
AS 
BEGIN
	declare @noshowdatetime DATETIME;
	declare @confirmdatetime DATETIME;

	SELECT @noshowdatetime = I.NoShowDateTime FROM INSERTED I; 
	SELECT @confirmdatetime = ConfirmedDateTime
	FROM dbo.ConfirmedBookings CB, INSERTED I WHERE CB.RequestID = I.RequestID;

	IF CAST(@noshowdatetime as FLOAT) <  CAST(@confirmdatetime as FLOAT)
		BEGIN
			RAISERROR('NoShowDateTime is earlier than ConfirmedDateTime. Cannot save to database.',-1,-1)
			ROLLBACK
		END
END

/* Trigger 4.3 */
CREATE TRIGGER CheckCompletedDateTime ON dbo.CompletedTrips
FOR INSERT, UPDATE
AS 
BEGIN
	declare @completeddatetime DATETIME;
	declare @confirmdatetime DATETIME;

	SELECT @completeddatetime = I.CompletedDateTime FROM INSERTED I; 
	SELECT @confirmdatetime = ConfirmedDateTime
	FROM dbo.ConfirmedBookings CB, INSERTED I WHERE CB.RequestID = I.RequestID;
	
	IF CAST(@completeddatetime as FLOAT) < CAST(@confirmdatetime as FLOAT)
		BEGIN
			RAISERROR('CompletedDateTime is earlier than ConfirmedDateTime. Cannot save to database.',-1,-1)
			ROLLBACK
		END
END


/* Trigger 6 */
CREATE TRIGGER UpdateMerit ON dbo.CompletedTrips
AFTER INSERT
AS
BEGIN
	declare @completed_requestID INT;
	declare @request_personID CHAR(9);

	SELECT @completed_requestID = I.RequestID FROM INSERTED I;
	SELECT @request_personID = R.Users_PersonID FROM dbo.Requests R WHERE R.RequestID = @completed_requestID;

	UPDATE dbo.Users SET Merits = Merits + 1 WHERE PersonID = @request_personID;
END


/* Trigger 7 */
CREATE TRIGGER UpdateDemeritCancelled ON dbo.CancelledBookings
AFTER INSERT
AS
BEGIN
	declare @cancelled_requestID INT;
	declare @request_personID CHAR(9);

	SELECT @cancelled_requestID = I.RequestID FROM INSERTED I;
	SELECT @request_personID = R.Users_PersonID FROM dbo.Requests R WHERE R.RequestID = @cancelled_requestID;

	UPDATE dbo.Users SET Demerits = Demerits + 1 WHERE PersonID = @request_personID;
END


/* Trigger 8 */
CREATE TRIGGER UpdateDemeritNoShow ON dbo.NoShowBookings
AFTER INSERT
AS
BEGIN
	declare @noshow_requestID INT;
	declare @request_personID CHAR(9);

	SELECT @noshow_requestID = I.RequestID FROM INSERTED I;
	SELECT @request_personID = R.Users_PersonID FROM dbo.Requests R WHERE R.RequestID = @noshow_requestID;

	UPDATE dbo.Users SET Demerits = Demerits + 5 WHERE PersonID = @request_personID;
END