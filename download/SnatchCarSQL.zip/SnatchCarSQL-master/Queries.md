# Queries

1. Find the average price of trips booked from 6pm to 9pm in December 2015.
2. Find the drivers who receive more than 100 ratings of 5 in the month of December 2015, and order them by their average ratings.
3. For all confirmed bookings in December 2015 that were eventually cancelled, find the average time from booking confirmation to booking cancellation.
4. Let us define the "latency" of an employee by the average that he/she takes to process a complaint. Find the employee with the smallest latency.
5. Let us consider the car models used by SnatchCar drivers. Produce a list that contains all car models and, for each model, the number of cars used for SnatchCar.