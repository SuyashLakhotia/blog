# Triggers

1. INSERT/UPDATE to Cars --> Check if 'CarPlateNum' has been assigned to Driver.
2. INSERT/UPDATE to ConfirmedBookings --> Check if Driver exists **AND** UPDATE/DELETE 'PersonID' in Drivers --> Cascade changes to ConfirmedBookings.
3. INSERT/UPDATE to Complaints --> Check if Employee exists **AND** UPDATE/DELETE 'PersonID' in Employees --> Cascade changes to Complaints.
4. INSERT/UPDATE to CancelledBookings, NoShowBookings & CompletedTrips --> Timestamps >= 'ConfirmedDateTime'.
5. ~~INSERT/UPDATE to ConfirmedBookings --> Check that PassengerNum <= SeatNum.~~
6. INSERT to CompletedTrips --> Add 'Merits' + 1 for Users.
7. INSERT to CancelledBookings --> Add 'Demerits' + 1 for Users.
8. INSERT to NoShowBookings --> Add 'Demerits' + 5 for Users.
