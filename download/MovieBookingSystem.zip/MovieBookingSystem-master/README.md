# MovieBookingSystem

This repo contains a CLI movie booking system written in Java on Eclipse. The project makes use of OOP concepts to create a basic system for a movie theater chain that can be used by the staff to add/remove movies & showtimes and by customers to make bookings, review movies and view old transactions.

****

***Disclaimer:*** This repo is no longer maintained and was submitted as part of the coursework assignment for CZ 2002 at NTU in AY15/16 Semester 1.
